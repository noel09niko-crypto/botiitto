import os
import sqlite3
from dotenv import load_dotenv
load_dotenv()

from src.ai_analyzer import generate_scenarios, get_client
from src.database import add_scenario, get_db_connection
from src.stock_analyzer import get_stock_data

def refresh_sells():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Etsi kaikki aktiiviset MYY/VÄLTÄ skenaariot
    sells = cursor.execute('''
        SELECT tickers, summary FROM scenarios 
        WHERE (recommendation LIKE "%MYY%" OR recommendation LIKE "%VÄLTÄ%") 
        AND is_active = 1
    ''').fetchall()
    
    if not sells:
        print("Ei löytynyt aktiivisia MYY/VÄLTÄ -suosituksia päivitettäväksi.")
        conn.close()
        return

    client = get_client()
    print(f"Löytyi {len(sells)} myyntisuositusta. Päivitetään uuden rakenteen mukaisiksi...")

    for row in sells:
        ticker = row['tickers']
        print(f"  Päivitetään {ticker}...")
        
        try:
            # Hae tuoreet tiedot
            stock_data = get_stock_data(ticker)
            change = stock_data.get('change_pct_1d', 0.0)
            
            # Simuloi uutisvirta (käytetään olemassa olevaa summarya pohjana)
            context = f"RE-ANALYZE THIS SELL CASE: {ticker}. Old summary: {row['summary']}. Current price change: {change}%."
            
            # Generoi uusi analyysi
            new_scenarios = generate_scenarios(context, f"TICKER: {ticker}, CHANGE: {change}%", client)
            
            if new_scenarios:
                # add_scenario deaktivoi automaattisesti vanhan version samalla tickerillä jos is_manual=True (tai is_active=1)
                # Tässä käytetään is_manual=True, jotta vanha poistuu ja uusi tulee tilalle suosikkeihin/listalle.
                add_scenario(new_scenarios[0], is_manual=True, price_change=change)
                print(f"  [OK] {ticker} päivitetty uudella rakenteella.")
            else:
                print(f"  [!] {ticker} analyysin generointi epäonnistui.")
        except Exception as e:
            print(f"  [!] Virhe päivitettäessä {ticker}: {e}")

    conn.close()

if __name__ == "__main__":
    refresh_sells()
