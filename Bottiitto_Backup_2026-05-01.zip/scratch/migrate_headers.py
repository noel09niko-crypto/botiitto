import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'bot_database.db')

def migrate():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    scenarios = cursor.execute('SELECT id, recommendation FROM scenarios').fetchall()
    
    for row in scenarios:
        rec = str(row['recommendation']).upper()
        sid = row['id']
        
        if 'MYY' in rec or 'VÄLTÄ' in rec:
            headers = {
                'summary_title': 'Yhtiön nykyinen tilanne',
                'global_title': 'Maailmanmarkkinoiden haasteet',
                'reasoning_title': 'Miksi osaketta kannattaa välttää?',
                'metrics_title': 'Hälyttävät tunnusluvut',
                'horizon_title': 'Milloin tilanne voi muuttua?',
                'history_title': 'Miten tähän on tultu?'
            }
        else:
            headers = {
                'summary_title': 'Pikakuvaus yhtiöstä',
                'global_title': 'Miksi maailman tilanne suosii yhtiötä?',
                'reasoning_title': 'Miksi juuri tämä osake nousee?',
                'metrics_title': 'Vahvat tunnusluvut',
                'horizon_title': 'Paras ostohetki ja seuranta',
                'history_title': 'Yhtiön tarina ja kasvu'
            }
            
        cursor.execute('''
            UPDATE scenarios 
            SET summary_title = ?, global_title = ?, reasoning_title = ?, 
                metrics_title = ?, horizon_title = ?, history_title = ?
            WHERE id = ?
        ''', (
            headers['summary_title'], headers['global_title'], headers['reasoning_title'],
            headers['metrics_title'], headers['horizon_title'], headers['history_title'],
            sid
        ))
        
    conn.commit()
    print(f"Päivitetty {len(scenarios)} analyysin otsikot.")
    conn.close()

if __name__ == "__main__":
    migrate()
