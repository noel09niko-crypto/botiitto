import os
from dotenv import load_dotenv
load_dotenv()
from src.ai_analyzer import generate_scenarios, get_client
from src.database import add_scenario
from src.stock_analyzer import get_stock_data

client = get_client()

# Testataan NVDA ja INTC
for t in ['NVDA', 'INTC']:
    try:
        data = get_stock_data(t)
        change = data.get('change_pct_1d', 0.0)
        news = f'{t} latest market movement and analyst view.'
        movers_text = f'PRICE CHANGE: {change}%'
        
        scenarios = generate_scenarios(news, movers_text, client)
        if scenarios:
            add_scenario(scenarios[0], price_change=change)
            print(f'[OK] {t} päivitetty. Muutos: {change}%')
        else:
            print(f'[X] {t} analyysi epäonnistui.')
    except Exception as e:
        print(f'[!] Virhe yhtiölle {t}: {e}')
