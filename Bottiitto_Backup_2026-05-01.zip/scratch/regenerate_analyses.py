"""
Regeneroi kaikki aktiiviset analyysit uudella kirjoitustyylillä.
Ajetaan kerran: python3 scratch/regenerate_analyses.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from dotenv import load_dotenv
load_dotenv()

from src.database import get_active_scenarios, get_favorite_scenarios, deactivate_scenario, add_scenario, init_db
from src.ai_analyzer import generate_scenarios, get_client

def regenerate_all():
    init_db()
    client = get_client()
    
    active = get_active_scenarios(limit=50)
    favs = get_favorite_scenarios()
    all_scens = active + [f for f in favs if f not in active]
    
    print(f"Regeneroidaan {len(all_scens)} analyysia...\n")
    
    for scen in all_scens:
        ticker = scen.get('tickers', 'YLEINEN')
        title = scen.get('title', '')[:60]
        is_fav = scen.get('is_favorite', False)
        
        print(f"→ {ticker}: {title}")
        
        # Rakenna konteksti vanhasta analyysista
        context = f"""Regeneroi tämä analyysi uudella, kiinnostavammalla kirjoitustyylillä.
Pidä sama sijoitusnäkemys mutta tee tekstistä selkeämpää, napakampaa ja kiinnostavampaa.

ALKUPERÄINEN ANALYYSI:
Osake: {ticker}
Otsikko: {scen.get('title', '')}
Yhtiö: {scen.get('summary', '')}
Maailmantilanne: {scen.get('global_context', '')}
Perustelut: {scen.get('reasoning', '')}
Numerot: {scen.get('metrics_explanation', '')}
Riskit: {scen.get('time_horizon', '')}
Exit: {scen.get('company_history', '')}
Suositus: {scen.get('recommendation', 'OSTA')}
Luottamus: {scen.get('confidence', 75)}
"""
        try:
            new_scens = generate_scenarios(context, f"TICKER: {ticker}", client)
            if new_scens:
                new = new_scens[0]
                # Säilytä alkuperäinen suositus ja confidence jos AI muuttaa niitä
                new['recommendation'] = scen.get('recommendation', new.get('recommendation', 'OSTA'))
                new['confidence'] = scen.get('confidence', new.get('confidence', 75))
                new['tickers'] = ticker  # Varmista oikea ticker
                
                deactivate_scenario(scen['id'], reason="Regeneroitu paremmalla kirjoitustyylillä")
                add_scenario(new, is_manual=True, is_pinned=scen.get('is_pinned', False),
                           price_change=scen.get('price_change_24h', 0.0))
                
                # Jos oli suosikki, merkitään uusi suosikiksi
                if is_fav:
                    from src.database import get_db_connection, _placeholder
                    conn = get_db_connection()
                    cur = conn.cursor()
                    p = _placeholder()
                    cur.execute(f"UPDATE scenarios SET is_favorite=1 WHERE tickers={p} AND is_active=1 ORDER BY id DESC LIMIT 1", (ticker,))
                    conn.commit()
                    conn.close()
                
                print(f"   ✅ Valmis: {new.get('title', '')[:60]}")
            else:
                print(f"   ⚠️  Ei tulosta, jätetään ennalleen")
        except Exception as e:
            print(f"   ❌ Virhe: {e}")
    
    print(f"\n✅ Kaikki {len(all_scens)} analyysia regeneroitu!")

if __name__ == "__main__":
    regenerate_all()
